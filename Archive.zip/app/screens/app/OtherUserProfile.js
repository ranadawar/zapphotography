import { StyleSheet, Text, View } from "react-native";
import React from "react";
import AppScreen from "../../components/AppScreen";

const OtherUserProfile = () => {
  return (
    <AppScreen>
      <View>
        <Text>OtherUserProfile</Text>
      </View>
    </AppScreen>
  );
};

export default OtherUserProfile;

const styles = StyleSheet.create({});
