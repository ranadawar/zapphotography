import { StyleSheet, Text, View } from "react-native";
import React from "react";

const OffersCard = () => {
  return (
    <View>
      <Text>OffersCard</Text>
    </View>
  );
};

export default OffersCard;

const styles = StyleSheet.create({});
